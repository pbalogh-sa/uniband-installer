tar -xf wireless-regdb-modified.tar.gz 
tar -xf crda-modified.tar.gz
cd wireless-regdb-modified/
sudo apt-get install python-m2crypto
make
sudo make install
cd ..
cd crda-modified/
cp ../wireless-regdb-modified/$USER.key.pub.pem pubkeys/
sudo apt-get install libgcrypt11-dev
make
sudo make install
sudo sh -c "echo 'REGDOMAIN=CN' > /etc/default/crda"

